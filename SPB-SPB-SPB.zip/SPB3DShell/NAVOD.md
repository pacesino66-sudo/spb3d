# SPB 3D Shell – Android projekt

Launcher, ktorý v celej obrazovke zobrazí tvoj 3D návrh a cez natívnu časť pridáva skutočné veci:

- zoznam nainštalovaných aplikácií s ich ikonami a spúšťanie ťuknutím (tlačidlo v strede docku),
- kontakty z telefónu (po prvom spustení sa opýta na povolenie),
- „Zavolať“ otvorí číselník a „Správa“ otvorí SMS pre vybraný kontakt,
- nastavenia (pravé tlačidlo docku) otvoria skutočné nastavenia Androidu: Wi‑Fi, Bluetooth, displej a ďalšie,
- tlačidlo Späť zavrie okno alebo obrazovku vo vnútri, launcher sa nezatvorí,
- tlačidlo Domov (alebo gesto domov) ťa vráti na prvý panel.

Webová časť je v `app/src/main/assets/index.html`. Je to ten istý súbor ako v náhľade, takže vzhľad je rovnaký.

## Ako dostať APK (inštalačný súbor)

### Cesta A: GitHub (nepotrebuješ počítač s Android Studiom)
1. Na github.com si urob účet a vytvor nový prázdny repozitár.
2. Nahraj doň celý obsah tejto zložky (vrátane skrytej zložky `.github`). Najľahšie z počítača: Add file → Upload files.
3. Otvor záložku **Actions** → **Zostaviť APK** → **Run workflow**. Trvá to asi 3 až 6 minút.
4. Po dobehnutí otvor ten beh a dole v časti **Artifacts** stiahni `spb3d-shell-apk`. V ZIP-e je súbor `app-debug.apk`.

### Cesta B: Android Studio (počítač)
1. Nainštaluj Android Studio, otvor v ňom túto zložku a počkaj na synchronizáciu.
2. Build → Build APK(s). Súbor nájdeš v `app/build/outputs/apk/debug/app-debug.apk`.

## Inštalácia na telefón
1. APK dostaň do telefónu a ťukni naň. Povoľ inštaláciu z neznámych zdrojov pre aplikáciu, z ktorej ho otváraš.
2. Otvor SPB 3D Shell. Keď to chceš mať ako hlavnú obrazovku: Nastavenia telefónu → Aplikácie → Predvolené aplikácie → Domovská aplikácia → SPB 3D Shell. Alebo stlač tlačidlo Domov a systém sa ťa opýta, ktorý launcher použiť.
3. Späť na pôvodný launcher sa vrátiš tým istým miestom v nastaveniach.

## Poznámky
- Je to ladiaca (debug) verzia, podpísaná ladiacim kľúčom. Na testovanie stačí. Na Google Play bude treba vlastný podpisový kľúč.
- Aplikácie, ktoré pridáš do okna „Moje aplikácie“, sa spúšťajú ťuknutím na zväčšený panel.
- Nastavenia launchera, poznámky a poloha valca sa ukladajú v telefóne.
- Ikony aplikácií sa berú z telefónu. Balíky ikon (Auric Dark a iné) sa na ne zatiaľ nepoužívajú.

## Hudba (widget na valci)
1. Prvý raz klepni v okne Hudba na tlačidlo **Povoliť prístup**. Otvoria sa nastavenia, zapni "SPB 3D Shell hudba".
2. Pusti pieseň v ľubovoľnom prehrávači (Spotify, YouTube Music, Poweramp…). Widget ukáže názov, obal, čas a ovláda play/pauza/ďalšia/predošlá, posuvník a hlasitosť.

## Dlhé podržanie ikony
V zozname aplikácií podrž ikonu: spustiť, zmeniť ikonu, presunúť do kategórie, skryť, informácie, odinštalovať.
Ozubené koliesko v zozname aplikácií = nastavenia plochy aplikácií (kategórie, zložky, stĺpce).
