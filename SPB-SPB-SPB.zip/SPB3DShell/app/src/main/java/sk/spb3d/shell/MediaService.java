package sk.spb3d.shell;

import android.service.notification.NotificationListenerService;

/**
 * Prázdna služba. Stačí, že je zapnutý prístup k oznámeniam, vďaka tomu launcher
 * smie čítať aktívne prehrávacie relácie (čo hrá) a ovládať ich.
 */
public class MediaService extends NotificationListenerService {
}
