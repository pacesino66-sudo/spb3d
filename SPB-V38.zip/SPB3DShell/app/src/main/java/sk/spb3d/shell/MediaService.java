package sk.spb3d.shell;

import android.app.Notification;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Stačí, že je zapnutý prístup k oznámeniam: launcher smie čítať prehrávacie relácie (čo hrá)
 * a zároveň si tu pamätá posledné oznámenia z Gmailu a Správ pre okná Pošta a Komunikácia.
 */
public class MediaService extends NotificationListenerService {
    private static final Map<String, ArrayList<Object[]>> STORE = new HashMap<String, ArrayList<Object[]>>();

    private static void put(StatusBarNotification sbn) {
        if (sbn == null) return;
        String pkg = sbn.getPackageName();
        if (!"com.google.android.gm".equals(pkg) && !"com.google.android.apps.messaging".equals(pkg)) return;
        Notification n = sbn.getNotification();
        if (n == null || n.extras == null) return;
        Bundle e = n.extras;
        CharSequence t = e.getCharSequence(Notification.EXTRA_TITLE), x = e.getCharSequence(Notification.EXTRA_TEXT);
        if (t == null) return;
        if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0 && x == null) return;
        synchronized (STORE) {
            ArrayList<Object[]> l = STORE.get(pkg);
            if (l == null) { l = new ArrayList<Object[]>(); STORE.put(pkg, l); }
            for (int i = l.size() - 1; i >= 0; i--) if (l.get(i)[3].equals(sbn.getKey())) l.remove(i);
            l.add(0, new Object[]{t.toString(), x == null ? "" : x.toString(), sbn.getPostTime(), sbn.getKey()});
            while (l.size() > 8) l.remove(l.size() - 1);
        }
    }

    public static String dump(String pkg) {
        JSONArray arr = new JSONArray();
        synchronized (STORE) {
            ArrayList<Object[]> l = STORE.get(pkg);
            if (l != null) for (Object[] o : l) {
                JSONArray r = new JSONArray();
                r.put(o[0]); r.put(o[1]); r.put(o[2]);
                arr.put(r);
            }
        }
        return arr.toString();
    }

    @Override
    public void onListenerConnected() {
        try {
            StatusBarNotification[] a = getActiveNotifications();
            if (a != null) for (StatusBarNotification s : a) put(s);
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        put(sbn);
    }
}
