package sk.spb3d.shell;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.content.pm.ResolveInfo;
import android.content.ContentUris;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import java.io.InputStream;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.AlarmClock;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import org.xmlpull.v1.XmlPullParser;
import java.util.List;
import java.util.Set;

/**
 * SPB 3D Shell: launcher, ktorý v celej obrazovke zobrazí webový návrh (assets/index.html)
 * a cez objekt "Android" mu dáva skutočné aplikácie, kontakty, volanie a nastavenia.
 */
public class MainActivity extends Activity {

    private static final int REQ_CONTACTS = 7;
    private static final int REQ_COMM = 8;
    private static final int REQ_PHOTO = 9;
    private long lastPhotoAsk = 0;
    private long lastAsk = 0;
    private static final int REQ_FILE = 8;
    private ValueCallback<Uri[]> fileCb;
    private Resources packRes;
    private String packPkg = "";
    private final Map<String, String> packMap = new HashMap<String, String>();

    /** Načíta appfilter.xml z balíčka ikon (ADW/Nova/Apex štandard). */
    private void loadPack(String pkg) {
        packRes = null; packPkg = ""; packMap.clear();
        if (pkg == null || pkg.length() == 0) return;
        try {
            Resources r = getPackageManager().getResourcesForApplication(pkg);
            XmlPullParser xp = null;
            int id = r.getIdentifier("appfilter", "xml", pkg);
            if (id != 0) xp = r.getXml(id);
            else {
                java.io.InputStream in = r.getAssets().open("appfilter.xml");
                xp = android.util.Xml.newPullParser();
                xp.setInput(in, "utf-8");
            }
            int ev = xp.getEventType();
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && "item".equals(xp.getName())) {
                    String comp = xp.getAttributeValue(null, "component"), dr = xp.getAttributeValue(null, "drawable");
                    if (comp != null && dr != null && comp.startsWith("ComponentInfo{") && comp.endsWith("}")) {
                        String key = comp.substring(14, comp.length() - 1);
                        if (!packMap.containsKey(key)) packMap.put(key, dr);
                    }
                }
                ev = xp.next();
            }
            packRes = r; packPkg = pkg;
        } catch (Exception e) {
            packRes = null; packPkg = ""; packMap.clear();
        }
    }

    private Drawable packIcon(String pkg, String cls) {
        if (packRes == null) return null;
        String dr = packMap.get(pkg + "/" + cls);
        if (dr == null) return null;
        int id = packRes.getIdentifier(dr, "drawable", packPkg);
        if (id == 0) return null;
        try { return packRes.getDrawable(id, null); } catch (Exception e) { return null; }
    }
    private WebView web;

    private final BroadcastReceiver pkgReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            js("window.__spbApps && window.__spbApps()");
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        web.setBackgroundColor(0xFF05070B);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (Exception ignored) { }
                    return true;
                }
                return false;
            }
        });
        loadPack(getSharedPreferences("spb", MODE_PRIVATE).getString("ipack", ""));
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                String[] acc = params.getAcceptTypes();
                String ty = (acc != null && acc.length > 0 && acc[0] != null && acc[0].length() > 0) ? acc[0] : "image/*";
                i.setType(ty);
                if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(Intent.createChooser(i, ty.startsWith("audio") ? "Vyber skladby" : "Vyber obrázok"), REQ_FILE);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }
        });
        web.loadUrl("file:///android_asset/index.html");

        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_REPLACED);
        f.addDataScheme("package");
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(pkgReceiver, f, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(pkgReceiver, f);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (Intent.ACTION_MAIN.equals(intent.getAction()) && intent.hasCategory(Intent.CATEGORY_HOME)) {
            js("window.__spbHome && window.__spbHome()");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE && fileCb != null) {
            Uri[] r = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    r = new Uri[n];
                    for (int k = 0; k < n; k++) r[k] = data.getClipData().getItemAt(k).getUri();
                } else if (data.getData() != null) r = new Uri[]{data.getData()};
            }
            fileCb.onReceiveValue(r);
            fileCb = null;
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onPause() {
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        try {
            unregisterReceiver(pkgReceiver);
        } catch (Exception ignored) { }
        super.onDestroy();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        // Launcher sa nezatvára: tlačidlo Späť len zavrie okno alebo obrazovku vo vnútri.
        js("window.__spbBack && window.__spbBack()");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CONTACTS && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            js("window.__spbContacts && window.__spbContacts()");
        }
        if (requestCode == REQ_PHOTO) {
            js("window.__spbPhotos && window.__spbPhotos()");
        }
        if (requestCode == REQ_COMM) {
            js("window.__spbComm && window.__spbComm()");
        }
    }

    private void js(final String code) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (web != null) web.evaluateJavascript(code, null);
            }
        });
    }

    private String iconData(Drawable d) {
        int sz = 96;
        Bitmap bm = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        d.setBounds(0, 0, sz, sz);
        d.draw(c);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.PNG, 100, bo);
        return "data:image/png;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
    }

    private void start(final Intent i) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } catch (Exception e) {
                    js("window.toast && 0");
                }
            }
        });
    }

    /** Funkcie, ktoré volá webová časť (objekt "Android"). */
    private class Bridge {

        @JavascriptInterface
        public boolean isNative() {
            return true;
        }

        @JavascriptInterface
        public String getApps() {
            JSONArray arr = new JSONArray();
            try {
                PackageManager pm = getPackageManager();
                Intent main = new Intent(Intent.ACTION_MAIN);
                main.addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> list = pm.queryIntentActivities(main, 0);
                Set<String> seen = new HashSet<String>();
                for (ResolveInfo r : list) {
                    String pkg = r.activityInfo.packageName;
                    if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
                    try {
                        JSONObject o = new JSONObject();
                        o.put("n", r.loadLabel(pm).toString());
                        o.put("p", pkg);
                        o.put("c", Build.VERSION.SDK_INT >= 26 ? r.activityInfo.applicationInfo.category : -1);
                        Drawable pi = packIcon(pkg, r.activityInfo.name);
                        o.put("i", iconData(pi != null ? pi : r.loadIcon(pm)));
                        arr.put(o);
                    } catch (Exception ignored) { }
                }
            } catch (Exception ignored) { }
            return arr.toString();
        }

        @JavascriptInterface
        public void launch(String pkg) {
            Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
            if (i != null) start(i);
        }

        @JavascriptInterface
        public String getContacts() {
            JSONArray arr = new JSONArray();
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, REQ_CONTACTS);
                    }
                });
                return arr.toString();
            }
            Cursor c = null;
            try {
                c = getContentResolver().query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER},
                        null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC");
                Set<String> seen = new HashSet<String>();
                while (c != null && c.moveToNext() && arr.length() < 600) {
                    String name = c.getString(0), num = c.getString(1);
                    if (name == null || num == null || !seen.add(name)) continue;
                    JSONArray row = new JSONArray();
                    row.put(name);
                    row.put(num);
                    arr.put(row);
                }
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.close();
            }
            return arr.toString();
        }

        private boolean commOk() {
            if (Build.VERSION.SDK_INT < 23) return true;
            boolean ok = checkSelfPermission(Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED;
            if (!ok && System.currentTimeMillis() - lastAsk > 20000) {
                lastAsk = System.currentTimeMillis();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        requestPermissions(new String[]{Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_SMS, Manifest.permission.READ_CONTACTS}, REQ_COMM);
                    }
                });
            }
            return ok;
        }

        private String nameOf(String number) {
            if (number == null) return "";
            Cursor c = null;
            try {
                c = getContentResolver().query(Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)),
                        new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME}, null, null, null);
                if (c != null && c.moveToFirst()) return c.getString(0);
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.close();
            }
            return number;
        }

        @JavascriptInterface
        public String callLog() {
            JSONArray arr = new JSONArray();
            if (!commOk()) return arr.toString();
            Cursor c = null;
            try {
                c = getContentResolver().query(CallLog.Calls.CONTENT_URI,
                        new String[]{CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE},
                        null, null, CallLog.Calls.DATE + " DESC");
                while (c != null && c.moveToNext() && arr.length() < 12) {
                    String num = c.getString(0), nm = c.getString(1);
                    JSONArray row = new JSONArray();
                    row.put(nm != null && nm.length() > 0 ? nm : (num == null || num.length() == 0 ? "Neznáme" : num));
                    row.put(num == null ? "" : num);
                    row.put(c.getInt(2));
                    row.put(c.getLong(3));
                    arr.put(row);
                }
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.close();
            }
            return arr.toString();
        }

        @JavascriptInterface
        public String smsList() {
            JSONArray arr = new JSONArray();
            if (!commOk()) return arr.toString();
            Cursor c = null;
            try {
                c = getContentResolver().query(Uri.parse("content://sms"),
                        new String[]{"address", "body", "date", "type"}, null, null, "date DESC");
                Set<String> seen = new HashSet<String>();
                int scanned = 0;
                while (c != null && c.moveToNext() && arr.length() < 8 && scanned++ < 300) {
                    String addr = c.getString(0);
                    if (addr == null || !seen.add(addr)) continue;
                    JSONArray row = new JSONArray();
                    row.put(nameOf(addr));
                    row.put(c.getString(1));
                    row.put(c.getLong(2));
                    row.put(c.getInt(3));
                    row.put(addr);
                    arr.put(row);
                }
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.close();
            }
            return arr.toString();
        }

        private String thumb(long id, String path, int px) {
            try {
                Uri u = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id);
                BitmapFactory.Options b = new BitmapFactory.Options();
                b.inJustDecodeBounds = true;
                InputStream in = getContentResolver().openInputStream(u);
                BitmapFactory.decodeStream(in, null, b);
                in.close();
                int sm = 1;
                while (b.outWidth / (sm * 2) >= px && b.outHeight / (sm * 2) >= px) sm *= 2;
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inSampleSize = sm;
                in = getContentResolver().openInputStream(u);
                Bitmap bm = BitmapFactory.decodeStream(in, null, o);
                in.close();
                if (bm == null) return "";
                int rot = 0;
                try {
                    if (path != null) {
                        int ori = new android.media.ExifInterface(path).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1);
                        if (ori == 6) rot = 90; else if (ori == 3) rot = 180; else if (ori == 8) rot = 270;
                    }
                } catch (Exception ignored) { }
                float k = Math.min(1f, (float) px / Math.max(bm.getWidth(), bm.getHeight()));
                Matrix m = new Matrix();
                m.postScale(k, k);
                if (rot != 0) m.postRotate(rot);
                Bitmap out = Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(), m, true);
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                out.compress(Bitmap.CompressFormat.JPEG, 80, bo);
                return "data:image/jpeg;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
            } catch (Exception e) {
                return "";
            }
        }

        /** Posledné fotky: all (5), shot, cam, dl (po 13). Položka = [id, dataUrl]. */
        @JavascriptInterface
        public String photos() {
            JSONObject o = new JSONObject();
            try {
                String perm = Build.VERSION.SDK_INT >= 33 ? "android.permission.READ_MEDIA_IMAGES" : Manifest.permission.READ_EXTERNAL_STORAGE;
                boolean ok = Build.VERSION.SDK_INT < 23 || checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
                o.put("perm", ok);
                if (!ok) {
                    if (System.currentTimeMillis() - lastPhotoAsk > 20000) {
                        lastPhotoAsk = System.currentTimeMillis();
                        final String pp = perm;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                requestPermissions(new String[]{pp}, REQ_PHOTO);
                            }
                        });
                    }
                    return o.toString();
                }
                String[] keys = {"all", "shot", "cam", "dl"};
                JSONArray[] lists = new JSONArray[4];
                for (int i = 0; i < 4; i++) lists[i] = new JSONArray();
                Map<String, String> cache = new HashMap<String, String>();
                Cursor c = null;
                try {
                    c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                            new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DATA},
                            null, null, MediaStore.Images.Media.DATE_ADDED + " DESC");
                    int scanned = 0;
                    while (c != null && c.moveToNext() && scanned++ < 800) {
                        long id = c.getLong(0);
                        String path = c.getString(1);
                        String lp = path == null ? "" : path.toLowerCase();
                        int cat = lp.contains("screenshot") ? 1 : (lp.contains("/dcim/") || lp.contains("/camera/")) ? 2 : lp.contains("/download") ? 3 : -1;
                        int[] targets = cat < 0 ? new int[]{0} : new int[]{0, cat};
                        for (int t : targets) {
                            int cap = t == 0 ? 5 : 13;
                            if (lists[t].length() >= cap) continue;
                            int px = lists[t].length() == 0 ? 640 : 200;
                            String ck = id + ":" + px;
                            String d = cache.get(ck);
                            if (d == null) { d = thumb(id, path, px); cache.put(ck, d); }
                            JSONArray row = new JSONArray();
                            row.put(String.valueOf(id));
                            row.put(d);
                            lists[t].put(row);
                        }
                        if (lists[0].length() >= 5 && lists[1].length() >= 13 && lists[2].length() >= 13 && lists[3].length() >= 13) break;
                    }
                } finally {
                    if (c != null) c.close();
                }
                for (int i = 0; i < 4; i++) o.put(keys[i], lists[i]);
            } catch (Exception ignored) { }
            return o.toString();
        }

        @JavascriptInterface
        public void openPhoto(String id) {
            try {
                Uri u = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, Long.parseLong(id));
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setDataAndType(u, "image/*");
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                start(i);
            } catch (Exception ignored) { }
        }

        private boolean torchOn = false;

        @JavascriptInterface
        public String toggles() {
            JSONObject o = new JSONObject();
            try {
                try {
                    android.net.wifi.WifiManager w = (android.net.wifi.WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                    o.put("wifi", w != null && w.isWifiEnabled());
                } catch (Exception ignored) { }
                try {
                    android.bluetooth.BluetoothAdapter b = android.bluetooth.BluetoothAdapter.getDefaultAdapter();
                    o.put("bt", b != null && b.isEnabled());
                } catch (Exception ignored) { }
                try {
                    o.put("air", Settings.Global.getInt(getContentResolver(), Settings.Global.AIRPLANE_MODE_ON, 0) == 1);
                } catch (Exception ignored) { }
                o.put("torch", torchOn);
            } catch (Exception ignored) { }
            return o.toString();
        }

        @JavascriptInterface
        public void tog(String kind) {
            try {
                if ("torch".equals(kind)) {
                    android.hardware.camera2.CameraManager cm = (android.hardware.camera2.CameraManager) getSystemService(Context.CAMERA_SERVICE);
                    torchOn = !torchOn;
                    cm.setTorchMode(cm.getCameraIdList()[0], torchOn);
                    return;
                }
                boolean q = Build.VERSION.SDK_INT >= 29;
                String act = Settings.ACTION_SETTINGS;
                if ("wifi".equals(kind)) act = q ? "android.settings.panel.action.INTERNET_CONNECTIVITY" : Settings.ACTION_WIFI_SETTINGS;
                else if ("data".equals(kind)) act = q ? "android.settings.panel.action.INTERNET_CONNECTIVITY" : Settings.ACTION_DATA_ROAMING_SETTINGS;
                else if ("bt".equals(kind)) act = Settings.ACTION_BLUETOOTH_SETTINGS;
                else if ("air".equals(kind)) act = Settings.ACTION_AIRPLANE_MODE_SETTINGS;
                else if ("nfc".equals(kind)) act = q ? "android.settings.panel.action.NFC" : Settings.ACTION_NFC_SETTINGS;
                else if ("vol".equals(kind)) act = q ? "android.settings.panel.action.VOLUME" : Settings.ACTION_SOUND_SETTINGS;
                else if ("loc".equals(kind)) act = Settings.ACTION_LOCATION_SOURCE_SETTINGS;
                else if ("hot".equals(kind)) act = "android.settings.TETHER_SETTINGS";
                else if ("dnd".equals(kind)) act = "android.settings.ZEN_MODE_SETTINGS";
                else if ("bright".equals(kind)) act = Settings.ACTION_DISPLAY_SETTINGS;
                else if ("bat".equals(kind)) act = Settings.ACTION_BATTERY_SAVER_SETTINGS;
                try {
                    start(new Intent(act));
                } catch (Exception e) {
                    start(new Intent(Settings.ACTION_SETTINGS));
                }
            } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public String notifs(String pkg) {
            return MediaService.dump(pkg);
        }

        @JavascriptInterface
        public void openUrl(String url) {
            try { start(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public void dial(String number) {
            start(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))));
        }

        @JavascriptInterface
        public void sms(String number) {
            start(new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number))));
        }

        @JavascriptInterface
        public void openSettings(String kind) {
            String a;
            if ("wifi".equals(kind)) a = Settings.ACTION_WIFI_SETTINGS;
            else if ("bt".equals(kind)) a = Settings.ACTION_BLUETOOTH_SETTINGS;
            else if ("data".equals(kind)) a = Settings.ACTION_WIRELESS_SETTINGS;
            else if ("display".equals(kind)) a = Settings.ACTION_DISPLAY_SETTINGS;
            else if ("sound".equals(kind)) a = Settings.ACTION_SOUND_SETTINGS;
            else if ("battery".equals(kind)) a = Settings.ACTION_BATTERY_SAVER_SETTINGS;
            else if ("storage".equals(kind)) a = Settings.ACTION_INTERNAL_STORAGE_SETTINGS;
            else if ("apps".equals(kind)) a = Settings.ACTION_APPLICATION_SETTINGS;
            else if ("security".equals(kind)) a = Settings.ACTION_SECURITY_SETTINGS;
            else a = Settings.ACTION_SETTINGS;
            start(new Intent(a));
        }

        @JavascriptInterface
        public void quick(String kind) {
            Intent i;
            if ("phone".equals(kind)) i = new Intent(Intent.ACTION_DIAL);
            else if ("camera".equals(kind)) i = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
            else if ("clock".equals(kind)) i = new Intent(AlarmClock.ACTION_SHOW_ALARMS);
            else if ("settings".equals(kind)) i = new Intent(Settings.ACTION_SETTINGS);
            else {
                i = new Intent(Intent.ACTION_MAIN);
                if ("message".equals(kind)) i.addCategory(Intent.CATEGORY_APP_MESSAGING);
                else if ("gallery".equals(kind)) i.addCategory(Intent.CATEGORY_APP_GALLERY);
                else if ("contacts".equals(kind)) i.addCategory(Intent.CATEGORY_APP_CONTACTS);
                else if ("calendar".equals(kind)) i.addCategory(Intent.CATEGORY_APP_CALENDAR);
                else if ("maps".equals(kind)) i.addCategory(Intent.CATEGORY_APP_MAPS);
                else if ("music".equals(kind)) i.addCategory(Intent.CATEGORY_APP_MUSIC);
            }
            start(i);
        }

        @JavascriptInterface
        public void wallpaper() {
            start(Intent.createChooser(new Intent(Intent.ACTION_SET_WALLPAPER), "Tapeta"));
        }

        @JavascriptInterface
        public void lockSettings() {
            start(new Intent(Settings.ACTION_SECURITY_SETTINGS));
        }

        @JavascriptInterface
        public String launchers() {
            JSONArray arr = new JSONArray();
            try {
                PackageManager pm = getPackageManager();
                Intent h = new Intent(Intent.ACTION_MAIN);
                h.addCategory(Intent.CATEGORY_HOME);
                Set<String> seen = new HashSet<String>();
                for (ResolveInfo r : pm.queryIntentActivities(h, 0)) {
                    String pkg = r.activityInfo.packageName;
                    if (!seen.add(pkg)) continue;
                    JSONObject o = new JSONObject();
                    o.put("n", r.loadLabel(pm).toString());
                    o.put("p", pkg);
                    o.put("i", iconData(r.loadIcon(pm)));
                    if (pkg.equals(getPackageName())) o.put("me", true);
                    arr.put(o);
                }
            } catch (Exception ignored) { }
            return arr.toString();
        }

        @JavascriptInterface
        public void openLauncher(String pkg) {
            Intent h = new Intent(Intent.ACTION_MAIN);
            h.addCategory(Intent.CATEGORY_HOME);
            h.setPackage(pkg);
            start(h);
        }

        @JavascriptInterface
        public void chooseHome() {
            try {
                start(new Intent(Settings.ACTION_HOME_SETTINGS));
            } catch (Exception e) {
                start(new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS));
            }
        }

        @JavascriptInterface
        public String iconPacks() {
            JSONArray arr = new JSONArray();
            try {
                PackageManager pm = getPackageManager();
                String[] acts = {"org.adw.launcher.THEMES", "com.novalauncher.THEME", "com.gau.go.launcherex.theme", "com.anddoes.launcher.THEME", "org.adw.launcher.icons.ACTION_PICK_ICON"};
                Set<String> seen = new HashSet<String>();
                for (String a : acts) {
                    for (ResolveInfo r : pm.queryIntentActivities(new Intent(a), 0)) {
                        String pkg = r.activityInfo.packageName;
                        if (!seen.add(pkg)) continue;
                        JSONObject o = new JSONObject();
                        o.put("n", r.loadLabel(pm).toString());
                        o.put("p", pkg);
                        arr.put(o);
                    }
                }
            } catch (Exception ignored) { }
            return arr.toString();
        }

        @JavascriptInterface
        public void setIconPack(String pkg) {
            getSharedPreferences("spb", MODE_PRIVATE).edit().putString("ipack", pkg == null ? "" : pkg).apply();
            loadPack(pkg);
        }

        @JavascriptInterface
        public void playSearch(String q) {
            try {
                start(new Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=" + Uri.encode(q) + "&c=apps")));
            } catch (Exception e) {
                start(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/search?q=" + Uri.encode(q) + "&c=apps")));
            }
        }

        @JavascriptInterface
        public void uninstall(String pkg) {
            start(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkg)));
        }

        @JavascriptInterface
        public void appInfo(String pkg) {
            start(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg)));
        }

        @JavascriptInterface
        public void openNotifAccess() {
            start(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
        }

        /** Stav hudby z aktívnej prehrávacej relácie (vyžaduje prístup k oznámeniam). */
        @JavascriptInterface
        public String musicState(String knownKey) {
            JSONObject o = new JSONObject();
            try {
                boolean acc = hasNotifAccess();
                o.put("access", acc);
                AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                int max = Math.max(1, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
                o.put("vol", am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / max);
                MediaController c = acc ? pickController() : null;
                o.put("has", false);
                if (c != null) {
                    MediaMetadata md = c.getMetadata();
                    PlaybackState ps = c.getPlaybackState();
                    if (md != null) {
                        String title = md.getString(MediaMetadata.METADATA_KEY_TITLE);
                        String artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST);
                        if (artist == null) artist = md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST);
                        o.put("has", true);
                        o.put("title", title == null ? "" : title);
                        o.put("artist", artist == null ? "" : artist);
                        o.put("dur", md.getLong(MediaMetadata.METADATA_KEY_DURATION));
                        String key = c.getPackageName() + "|" + title + "|" + artist;
                        o.put("key", key);
                        if (!key.equals(knownKey)) {
                            Bitmap b = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
                            if (b == null) b = md.getBitmap(MediaMetadata.METADATA_KEY_ART);
                            if (b == null) b = md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
                            if (b != null) {
                                Bitmap sm = Bitmap.createScaledBitmap(b, 192, 192, true);
                                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                                sm.compress(Bitmap.CompressFormat.JPEG, 82, bo);
                                o.put("art", "data:image/jpeg;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP));
                            }
                        }
                    }
                    if (ps != null) {
                        boolean playing = ps.getState() == PlaybackState.STATE_PLAYING;
                        long pos = ps.getPosition();
                        if (playing) pos += (long) ((SystemClock.elapsedRealtime() - ps.getLastPositionUpdateTime()) * ps.getPlaybackSpeed());
                        o.put("playing", playing);
                        o.put("pos", pos);
                    }
                }
            } catch (Exception ignored) { }
            return o.toString();
        }

        /** Príkazy: play, pause, next, prev, seek:ms, vol:0-100. */
        @JavascriptInterface
        public void music(String cmd) {
            try {
                if (cmd.startsWith("vol:")) {
                    AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                    int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(max * Integer.parseInt(cmd.substring(4)) / 100f), 0);
                    return;
                }
                MediaController c = hasNotifAccess() ? pickController() : null;
                if (c == null) return;
                MediaController.TransportControls t = c.getTransportControls();
                if (cmd.equals("play")) t.play();
                else if (cmd.equals("pause")) t.pause();
                else if (cmd.equals("next")) t.skipToNext();
                else if (cmd.equals("prev")) t.skipToPrevious();
                else if (cmd.startsWith("seek:")) t.seekTo(Long.parseLong(cmd.substring(5)));
            } catch (Exception ignored) { }
        }
    }

    private boolean hasNotifAccess() {
        String s = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return s != null && s.contains(getPackageName());
    }

    private MediaController pickController() {
        try {
            MediaSessionManager msm = (MediaSessionManager) getSystemService(Context.MEDIA_SESSION_SERVICE);
            List<MediaController> l = msm.getActiveSessions(new ComponentName(this, MediaService.class));
            if (l == null || l.isEmpty()) return null;
            for (MediaController c : l) {
                PlaybackState ps = c.getPlaybackState();
                if (ps != null && ps.getState() == PlaybackState.STATE_PLAYING) return c;
            }
            return l.get(0);
        } catch (SecurityException e) {
            return null;
        }
    }
}
